make clean
make 
make qemu
